#!/bin/sh

gcc src/*.c -o nat-hole-punch
